#Chainer
from chainer import cuda, Function, gradient_check, report, training, utils, Variable
from chainer import datasets, iterators, optimizers, serializers
from chainer.datasets import tuple_dataset
from chainer import Link, Chain, ChainList
import chainer.functions as F
import chainer.links as L
from chainer import training
from chainer.training import extensions
import chainer

#tkinter
import tkinter as tk
import tkinter.ttk as ttk
import tkinter.font as font
import tkinter.scrolledtext as sc
from tkinter import filedialog

#その他
from Network import Network, Model  # @UnresolvedImport
import numpy as np
import re
import subprocess
import json
import pickle
import os

list_datasets = ("MNIST Dataset", "CIFAR-10 Dataset", "CIFAR-100 Dataset")
Labelnum = {"MNIST Dataset":10, "CIFAR-10 Dataset":10, "CIFAR-100 Dataset":100}
list_layers = ("Convolution", "maxPooling", "avePooling", "BatchNormalization", "Affine", "Sigmoid", "ReLU", "LeakyReLU", "Softmax", "Dropout", "End")
list_layers_short = {"Convolution":"Conv", "maxPooling":"m-Pool", "avePooling":"a-Pool", "BatchNormalization":"B-Norm", "Affine":"Affine", "Sigmoid":"Sigmoid",
                     "ReLU":"ReLU", "LeakyReLU":"L_ReLU", "Softmax":"Softmax", "Dropout":"Dropout", "End":"End"}
list_paramers = ({"出力数":10, "フィルタサイズ":3, "ストライド":1, "パディング":0},
                 {"フィルタサイズ":2, "ストライド":2, "パディング":0},
                 {"フィルタサイズ":2, "ストライド":2, "パディング":0},
                 {},
                 {"出力数":10},
                 {},
                 {},
                 {"傾き":0.2},
                 {},
                 {"損失確率":0.5},
                 {})

class GUI:
    def __init__(self):
        if os.path.exists("network"):
            os.makedirs("network")

        self.train, self.test = datasets.get_mnist(ndim=3)
        self.inputsize = self.train[0][0].shape

        self.root = tk.Tk()
        self.root.title("Network Creator")
        self.root.geometry("450x900")
        #self.root.protocol("WM_DELETE_WINDOW", self.closeUI)

        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both")

        self.frameC = tk.Frame(self.nb)
        self.nb.add(self.frameC, text="学習条件")

        self.frameLS = tk.Frame(self.nb)
        self.nb.add(self.frameLS, text="学習")

        frameN = tk.Frame(self.frameC)
        frameN.pack(fill="x")
        l_name = tk.Label(frameN, text="ネットワーク名：", font=("", 12))
        l_name.grid(row=0, column=0, padx=4, pady=2, sticky=tk.W)
        self.v_name = tk.StringVar()
        self.v_name.set("Network")
        e_name = tk.Entry(frameN, textvariable=self.v_name, width=20, font=("", 12))
        e_name.grid(row=0, column=1, padx=10, pady=10)

        self.frameDS = tk.Frame(self.frameC)
        self.frameDS.pack(fill="x", padx=10)

        self.v_ds = tk.StringVar()
        self.v_ds.set(list_datasets[0])
        self.cb_ds = ttk.Combobox(self.frameDS, textvariable=self.v_ds, width=18, font=font.Font(self.root, family="",size=12))
        self.cb_ds['values'] = list_datasets
        self.cb_ds.bind('<<ComboboxSelected>>' , self.selected_ds)
        self.cb_ds.grid(row=0, column=0, columnspan=2, padx=2, pady=2, sticky=tk.W)

        self.l_dsi = tk.Label(self.frameDS, text="入力サイズ："+str(self.train[0][0].shape), font=("", 12))
        self.l_dsi.grid(row=0, column=1, columnspan=2, padx=4, pady=2, sticky=tk.W)

        frameTrain = tk.Frame(self.frameDS)
        frameTrain.grid(row=1, column=0)

        l_dstr = tk.Label(frameTrain, text="学習データ数：", font=("", 12))
        l_dstr.grid(row=1, column=0, padx=2, pady=2, sticky=tk.W)
        self.v_dstr = tk.IntVar()
        self.v_dstr.set(len(self.train))
        e_dstr = tk.Entry(frameTrain, textvariable=self.v_dstr, width=8, font=("", 12))
        e_dstr.grid(row=1, column=1, padx=2, pady=2, sticky=tk.W)

        self.var_addI = tk.BooleanVar()
        self.var_addI.set(False)
        self.var_addIn = tk.IntVar()
        self.var_addIn.set(60000)
        self.var_addG = tk.BooleanVar()
        self.var_addG.set(False)
        self.var_addGn = tk.IntVar()
        self.var_addGn.set(60000)
        self.var_addGg = tk.DoubleVar()
        self.var_addGg.set(1.5)

        frame_addition = tk.Frame(frameTrain)
        frame_addition.grid(row=2, column=0, columnspan=5, padx=3, sticky=tk.W)
        cb_addI = tk.Checkbutton(frame_addition, variable=self.var_addI, text="左右反転", font=("", 12))
        cb_addI.bind("<Button-1>", self.switch_addI)
        cb_addI.grid(row=0, column=0, padx=2, pady=3, sticky=tk.W)
        li = tk.Label(frame_addition, text="データ数：", font=("", 12))
        li.grid(row=1, column=0, padx=2, pady=3, sticky=tk.W)
        self.entry_addI = tk.Entry(frame_addition, width=8, textvariable=self.var_addIn, font=("", 12), state=tk.DISABLED)
        self.entry_addI.grid(row=1, column=1, padx=2, pady=3, sticky=tk.W)
        cb_addG = tk.Checkbutton(frame_addition, variable=self.var_addG, text="ガンマ変換", font=("", 12))
        cb_addG.bind("<Button-1>", self.switch_addG)
        cb_addG.grid(row=2, column=0, padx=2, pady=3, sticky=tk.W)
        lgn = tk.Label(frame_addition, text="データ数：", font=("", 12))
        lgn.grid(row=3, column=0, padx=2, pady=3, sticky=tk.W)
        self.entry_addGn = tk.Entry(frame_addition, width=8, textvariable=self.var_addGn, font=("", 12), state=tk.DISABLED)
        self.entry_addGn.grid(row=3, column=1, padx=2, pady=3, sticky=tk.W)
        lgg = tk.Label(frame_addition, text="ガンマ：", font=("", 12))
        lgg.grid(row=4, column=0, padx=2, pady=3, sticky=tk.W)
        self.entry_addGg = tk.Entry(frame_addition, width=8, textvariable=self.var_addGg, font=("", 12), state=tk.DISABLED)
        self.entry_addGg.grid(row=4, column=1, padx=2, pady=3, sticky=tk.W)

        frameTest = tk.Frame(self.frameDS)
        frameTest.grid(row=1, column=1)

        self.var_addI2 = tk.BooleanVar()
        self.var_addI2.set(False)
        self.var_addIn2 = tk.IntVar()
        self.var_addIn2.set(60000)
        self.var_addG2 = tk.BooleanVar()
        self.var_addG2.set(False)
        self.var_addGn2 = tk.IntVar()
        self.var_addGn2.set(60000)
        self.var_addGg2 = tk.DoubleVar()
        self.var_addGg2.set(1.5)

        l_dste = tk.Label(frameTest, text="テストデータ数：", font=("", 12))
        l_dste.grid(row=1, column=2, padx=2, pady=2, sticky=tk.W)
        self.v_dste = tk.IntVar()
        self.v_dste.set(len(self.test))
        e_dste = tk.Entry(frameTest, textvariable=self.v_dste, width=8, font=("", 12))
        e_dste.grid(row=1, column=3, padx=2, pady=2, sticky=tk.W)

        frame_addition2 = tk.Frame(frameTest)
        frame_addition2.grid(row=2, column=0, columnspan=5, padx=3, sticky=tk.W)
        cb_addI2 = tk.Checkbutton(frame_addition2, variable=self.var_addI2, text="左右反転", font=("", 12))
        cb_addI2.bind("<Button-1>", self.switch_addI2)
        cb_addI2.grid(row=0, column=0, padx=2, pady=3, sticky=tk.W)
        li2 = tk.Label(frame_addition2, text="データ数：", font=("", 12))
        li2.grid(row=1, column=0, padx=2, pady=3, sticky=tk.W)
        self.entry_addI2 = tk.Entry(frame_addition2, width=8, textvariable=self.var_addIn2, font=("", 12), state=tk.DISABLED)
        self.entry_addI2.grid(row=1, column=1, padx=2, pady=3, sticky=tk.W)
        cb_addG2 = tk.Checkbutton(frame_addition2, variable=self.var_addG2, text="ガンマ変換", font=("", 12))
        cb_addG2.bind("<Button-1>", self.switch_addG2)
        cb_addG2.grid(row=2, column=0, padx=2, pady=3, sticky=tk.W)
        lgn2 = tk.Label(frame_addition2, text="データ数：", font=("", 12))
        lgn2.grid(row=3, column=0, padx=2, pady=3, sticky=tk.W)
        self.entry_addGn2 = tk.Entry(frame_addition2, width=8, textvariable=self.var_addGn2, font=("", 12), state=tk.DISABLED)
        self.entry_addGn2.grid(row=3, column=1, padx=2, pady=3, sticky=tk.W)
        lgg2 = tk.Label(frame_addition2, text="ガンマ：", font=("", 12))
        lgg2.grid(row=4, column=0, padx=2, pady=3, sticky=tk.W)
        self.entry_addGg2 = tk.Entry(frame_addition2, width=8, textvariable=self.var_addGg2, font=("", 12), state=tk.DISABLED)
        self.entry_addGg2.grid(row=4, column=1, padx=2, pady=3, sticky=tk.W)

        frameS = tk.LabelFrame(self.frameC, text="構成", font=("", 15, "bold"))
        frameS.pack(fill="x")

        buttonAdd = tk.Button(frameS, text="追加", font=("", 12))
        buttonAdd.bind("<Button-1>", self.addLayer)
        buttonAdd.grid(row=0, column=0, padx=5, pady=3, sticky=tk.W)

        buttonClear = tk.Button(frameS, text="全削除", font=("", 12))
        buttonClear.bind("<Button-1>", self.clearLayer)
        buttonClear.grid(row=0, column=1, pady=3, sticky=tk.W)

        buttonClear = tk.Button(frameS, text="更新", font=("", 12))
        buttonClear.bind("<Button-1>", self.update)
        buttonClear.grid(row=0, column=2, pady=3, sticky=tk.W)

        buttonRef = tk.Button(frameS, text="ネットワーク参照", font=("", 12))
        buttonRef.bind("<Button-1>", self.refNetwork)
        buttonRef.grid(row=0, column=3, pady=3, sticky=tk.W)

        self.layer_frames = []
        self.layers = []
        self.layer_names = []
        self.layer_params = []
        self.outputSizes = [self.inputsize]

        self.cl = tk.Canvas(frameS, width=400, height=260)
        self.cl.bind_all("<MouseWheel>", self.on_mousewheel)
        self.cl.unbind_class("TCombobox", "<MouseWheel>")
        self.cl.grid(row=1, column=0, rowspan=10, columnspan=10, padx=5, pady=3, sticky=tk.N+tk.E+tk.W+tk.S)
        self.scrollcursor = 0
        self.scroll = tk.Scrollbar(frameS, orient=tk.VERTICAL, command=self.cl.yview)
        self.scroll.grid(row=1, column=10, rowspan=10, sticky=(tk.N, tk.S))
        self.cl["yscrollcommand"] = self.scroll.set

        self.frameL = tk.Frame(self.cl)
        self.frameL.bind("<Configure>", self.set_Scrollregion)
        self.cl.create_window(0, 0, window = self.frameL, anchor=tk.NW)

        frameE = tk.Frame(self.frameC)
        frameE.pack(fill="x", padx=10, pady=10)
        c = 0

        le = tk.Label(frameE, text="エポック数：", font=("", 12))
        le.grid(row=c, column=0, padx=5, pady=2)
        self.ve = tk.IntVar()
        self.ve.set(30)
        ee = tk.Entry(frameE, textvariable=self.ve, width=10, font=("", 12))
        ee.grid(row=c, column=1, pady=2)
        c += 1

        lmb = tk.Label(frameE, text="ミニバッチサイズ：", font=("", 12))
        lmb.grid(row=c, column=0, padx=5, pady=2)
        self.vmb = tk.IntVar()
        self.vmb.set(100)
        emb = tk.Entry(frameE, textvariable=self.vmb, width=10, font=("", 12))
        emb.grid(row=c, column=1, pady=2)
        c +=1

        self.EnableGPU = tk.BooleanVar()
        self.EnableGPU.set(self.availableGPU())
        checkgpu = tk.Checkbutton(frameE, text="GPUを使用", variable=self.EnableGPU, font=("", 12))
        checkgpu.grid(row=c, column=0, padx=5, pady=2)
        #lgpu = tk.Label(frameE, textvariable=self.EnableGPU, font=("", 12))
        #lgpu.grid(row=c, column=1, pady=2, sticky=tk.W)
        if not self.EnableGPU.get():
            checkgpu["state"] = tk.DISABLED
            #lgpu["state"] = tk.DISABLED
        c += 1

        frameLearn = tk.Frame(self.frameLS)
        frameLearn.pack(fill="both", padx=10, pady=10)

        self.console = sc.ScrolledText(frameLearn, width=50, font=("", 12))
        self.console.grid(row=0, column=0, columnspan=5, padx=2, pady=2)

        self.buttonName = tk.StringVar()
        self.buttonName.set("確認")
        buttonLearn = tk.Button(frameLearn, textvariable=self.buttonName, font=("", 12))
        buttonLearn.bind("<Button-1>", self.learn)
        buttonLearn.grid(row=1, column=4, padx=2, pady=2)

        self.net = None
        self.model = None
        self.epoch_now = 0

    def getRoot(self):
        return self.root

    def set_Scrollregion(self, event=None):
        self.cl.configure(scrollregion=self.cl.bbox("all"))
        self.cl.yview_scroll(self.scrollcursor, "units")

    def on_mousewheel(self, event=None):
        #print(event.delta)
        self.scrollcursor = -1*int(event.delta/abs(event.delta))
        self.cl.yview_scroll(self.scrollcursor, "units")

    def selected_ds(self, event=None):
        dataset = self.v_ds.get()
        i = list_datasets.index(dataset)

        if i == 0:
            self.train, self.test = datasets.get_mnist(ndim=3)
            self.inputsize = self.train[0][0].shape
        elif i == 1:
            self.train, self.test = datasets.get_cifar10()
            self.inputsize = self.train[0][0].shape
        elif i == 2:
            self.train, self.test = datasets.get_cifar100()
            self.inputsize = self.train[0][0].shape
        else:
            self.train, self.test = None, None

        if self.train != None:
            self.outputSizes[0] = self.inputsize
            self.l_dsi.configure(text = "入力サイズ："+str(self.inputsize))
            self.v_dstr.set(len(self.train))
            self.v_dste.set(len(self.test))

        self.var_addIn.set(len(self.train))
        self.var_addGn.set(len(self.train))
        self.var_addIn2.set(len(self.test))
        self.var_addGn2.set(len(self.test))
        self.update(fromChange=True)

    def addLayer(self, event=None, layer=None, lname=None, lparam=None):
        widgets = {}

        frame= tk.Frame(self.frameL, relief=tk.GROOVE, borderwidth=3)
        frame.pack(fill="x", padx=10, pady=4)
        widgets["parent"] = frame

        layers = [v.get() for v in self.layers]

        v_l = tk.StringVar()
        v_l.set("None")
        for l in layers:
            if "Affine" in l:
                v_l.set(list_layers[3])
        if layer != None:
            v_l.set(layer)
        if v_l.get() == "None":
            v_l.set(list_layers[0])
        self.layers.append(v_l)
        widgets["layer"] = v_l
        cb_l = ttk.Combobox(frame, textvariable=v_l, width=12, font=font.Font(frame, family="",size=12), state='readonly')
        cb_l['values'] = list_layers
        cb_l.bind('<<ComboboxSelected>>' , self.selected_layer)
        cb_l.grid(row=0, column=0, padx=2, pady=2, sticky=tk.W)
        widgets["selector"] = cb_l

        vn = tk.StringVar()
        if lname != None:
            vn.set(lname)
        else:
            vn.set(self.setName(v_l.get()))
        en = tk.Entry(frame, textvariable=vn, width=10, font=("", 12))
        en.grid(row=0, column=1, padx=2, pady=2, sticky=tk.W)
        self.layer_names.append(vn)
        widgets["layerName"] = vn

        buttonD = tk.Button(frame, text="削除", font=("", 12))
        buttonD.bind("<Button-1>", self.deleteLayer)
        buttonD.grid(row=0, column=2, padx=2, pady=2, sticky=tk.W)
        widgets["deleteButton"] = buttonD

        i = list_layers.index(v_l.get())
        frameP = self.get_Parameters(frame, i, init_param=lparam)
        widgets["paramFrame"] = frameP
        frameP.grid(row=1, column=0, columnspan=3, padx=10, pady=2, sticky=tk.W)

        l_out = tk.Label(frame, text="output：", font=("",12))
        l_out.grid(row=2, column=0, padx=10, pady=2, sticky=tk.W)
        outsize = tk.StringVar()
        widgets["outputSize"] = outsize
        s = self.get_outputSize(self.outputSizes[-1], v_l.get(), self.layer_params[-1])
        outsize.set(s)
        self.outputSizes.append(s)
        l_outsize = tk.Label(frame, textvariable=outsize, font=("", 12))
        l_outsize.grid(row=2, column=1, padx=10, pady=2, sticky=tk.W)

        self.layer_frames.append(widgets)

    def setName(self, layer):
        if layer == "End":
            return layer
        names = [v.get() for v in self.layer_names]
        for i in range(1, len(names)+2):
            if not list_layers_short[layer]+str(i) in names:
                return list_layers_short[layer]+str(i)
        return list_layers_short[layer]+"1"

    def selected_layer(self, event):
        i = [f["selector"] for f in self.layer_frames].index(event.widget)
        f = self.layer_frames[i]
        l_name = f["layer"].get()
        l_index = list_layers.index(l_name)

        f["paramFrame"].destroy()

        f["layerName"].set(self.setName(l_name))
        p = self.change_Parameters(f["parent"], l_index, i)
        p.grid(row=1, column=0, columnspan=3, padx=10, pady=2, sticky=tk.W)
        f["paramFrame"] = p

        size = self.get_outputSize(self.outputSizes[i], l_name, self.layer_params[i])
        if size != None:
            f["outputSize"].set(size)

        else:
            f["outputSize"].set("Error！")

        self.update(fromChange=True, numD=i)

    def get_Parameters(self, p_frame, i, init_param=None):
        ps = list_paramers[i]
        frame = tk.Frame(p_frame)

        params = []

        c = 0
        for p, d in ps.items():
            label = tk.Label(frame, text=p+"：", font=("", 12))
            label.grid(row=c, column=0, padx=2, pady=2)
            v = 0
            f_fs = ["Dropout", "LeakyReLU"]
            if list_layers[i] in f_fs:
                v = tk.DoubleVar()
            else:
                v = tk.IntVar()
            params.append(v)
            if init_param != None:
                v.set(init_param[len(params)-1])
            elif d != None:
                v.set(d)
            entry = tk.Entry(frame, textvariable=v, font=("", 12))
            entry.bind("<KeyRelease>", self.update)
            entry.grid(row=c, column=1, padx=2, pady=2)
            c += 1

        self.layer_params.append(params)

        return frame

    def change_Parameters(self, p_frame, i, layernum):
        ps = list_paramers[i]
        frame = tk.Frame(p_frame)

        params = []

        c = 0
        for p, d in ps.items():
            label = tk.Label(frame, text=p+"：", font=("", 12))
            label.grid(row=c, column=0, padx=2, pady=2)
            v = 0
            f_fs = ["Dropout", "LeakyReLU"]
            if list_layers[i] in f_fs:
                v = tk.DoubleVar()
            else:
                v = tk.IntVar()
            params.append(v)
            if d != None:
                v.set(d)
            entry = tk.Entry(frame, textvariable=v, font=("", 12))
            entry.bind("<KeyRelease>", self.update)
            entry.grid(row=c, column=1, padx=2, pady=2)
            c += 1

        self.layer_params[layernum] = params

        return frame

    def refNetwork(self, event):
        typ = [('ネットワーク構成ファイル','*.pkl')]
        dir = 'networks\\'
        fle = filedialog.askopenfilename(filetypes = typ, initialdir = dir)

        try:

            with open(fle, 'rb') as f:
                const = pickle.load(f)

            self.v_ds.set(const["dataset"])
            self.selected_ds()
            layers = const["layers"]
            lnames = const["names"]
            lparams = const["params"]

            for i in range(len(layers)):
                self.addLayer(layer=layers[i], lname=lnames[i], lparam=lparams[i])

        except:
            pass

    def get_outputSize(self, inputSize, layer, params):
        param = [v.get() for v in params]
        try:
            if layer == list_layers[0]:
                h = int((inputSize[2] + 2*param[3] - param[1]) / param[2] +1)
                w = int((inputSize[1] + 2*param[3] - param[1]) / param[2] +1)
                if h*w <= 0:
                    return None
                return (param[0], w, h)

            elif layer == list_layers[1]:
                h = int((inputSize[2] + 2*param[2] - param[0]) / param[1] +1)
                w = int((inputSize[1] + 2*param[2] - param[0]) / param[1] +1)
                if h*w <= 0:
                    return None
                return (inputSize[0], w, h)

            elif layer == list_layers[2]:
                h = int((inputSize[2] + 2*param[2] - param[0]-1) / param[1] +1)
                w = int((inputSize[1] + 2*param[2] - param[0]-1) / param[1] +1)
                if h*w <= 0:
                    return None
                return (inputSize[0], w, h)

            elif layer == list_layers[4]:
                return (param[0])
            else:
                return inputSize
        except:
            return None

    def deleteLayer(self, event=None):
        num = -1
        for i in range(len(self.layer_frames)):
            if self.layer_frames[i]["deleteButton"] == event.widget:
                num = i
                break
        self.layer_frames.pop(num)["parent"].destroy()
        self.layer_names.pop(num)
        self.layer_params.pop(num)
        self.layers.pop(num)

        """
        self.cl.delete("all")
        self.frameL.pack_forget()
        self.cl.create_window(0, 0, window = self.frameL, anchor=tk.NW)
        for f in self.layer_frames:
            f["parent"].pack(fill="x")
        """
        self.update(fromDelete=True, numD=num)

    def clearLayer(self, event=None):
        """
        self.cl.delete("all")
        self.frameL = tk.Frame(self.cl)
        self.cl.create_window(0, 0, window = self.frameL, anchor=tk.NW)
        """
        for f in self.layer_frames:
            f["parent"].destroy()
        self.layer_frames.clear()
        self.layer_names.clear()
        self.layer_params.clear()
        self.layers.clear()
        self.outputSizes = [self.outputSizes[0]]

    def update(self, event=None, fromDelete=False, fromChange=False, numD=0):
        #num = -1
        if fromDelete:
            for f in range(numD, len(self.layer_frames)):
                size = self.get_outputSize(self.outputSizes[f],
                                                self.layer_frames[f]["layer"].get(),
                                                self.layer_params[f])
                if self.outputSizes[f] != None:
                    if size != None:
                        self.outputSizes[f+1] = size
                        self.layer_frames[f]["outputSize"].set(size)
                    else:
                        self.outputSizes[f+1] = size
                        self.layer_frames[f]["outputSize"].set("Error！")
                else:
                    self.outputSizes[f+1] = size
                    self.layer_frames[f]["outputSize"].set("Error！")

        elif fromChange:
            for f in range(numD, len(self.layer_frames)):
                if self.outputSizes[f] != None:
                    size = self.get_outputSize(self.outputSizes[f],
                                                self.layer_frames[f]["layer"].get(),
                                                self.layer_params[f])
                    if size != None:
                        self.outputSizes[f+1] = size
                        self.layer_frames[f]["outputSize"].set(size)
                    else:
                        self.outputSizes[f+1] = size
                        self.layer_frames[f]["outputSize"].set("Error！")
                else:
                    self.outputSizes[f+1] = size
                    self.layer_frames[f]["outputSize"].set("Error！")
        else:
            if re.match(r"[0-9]", event.keysym):
                for fn in range(len(self.layer_frames)):
                    if event.widget.winfo_parent() == str(self.layer_frames[fn]["paramFrame"]):
                        num = fn
                        break

                if num == -1:
                    return

                for f in range(num, len(self.layer_frames)):
                    size = self.get_outputSize(self.outputSizes[f],
                                                    self.layer_frames[f]["layer"].get(),
                                                    self.layer_params[f])
                    if self.outputSizes[f] != None:
                        if size != None:
                            self.outputSizes[f+1] = size
                            self.layer_frames[f]["outputSize"].set(size)
                        else:
                            self.outputSizes[f+1] = size
                            self.layer_frames[f]["outputSize"].set("Error！")
                    else:
                        self.outputSizes[f+1] = size
                        self.layer_frames[f]["outputSize"].set("Error！")
            else:
                for f in range(numD, len(self.layer_frames)):
                    size = self.get_outputSize(self.outputSizes[f],
                                                self.layer_frames[f]["layer"].get(),
                                                self.layer_params[f])
                    if self.outputSizes[f] != None:
                        if size != None:
                            self.outputSizes[f+1] = size
                            self.layer_frames[f]["outputSize"].set(size)
                        else:
                            self.outputSizes[f+1] = size
                            self.layer_frames[f]["outputSize"].set("Error！")
                    else:
                        self.outputSizes[f+1] = size
                        self.layer_frames[f]["outputSize"].set("Error！")

    def availableGPU(self):
        try:
            chainer.cuda.get_device_from_id(0)  # @UndefinedVariable
            return True
        except:
            return False

    def learn(self, event=None):
        mode = self.buttonName.get()
        layers =[v.get() for v in self.layers]
        #self.layers = []
        #self.layer_names = []
        #self.layer_params = []

        if mode == "確認":
            self.console.insert(tk.END, "Checking Network and Learning Setting ...\n")
            for i in self.outputSizes:
                if i == None:
                    self.console.insert(tk.END, "    Layers' Outputsize ... ERROR\n\n")
                    return
            self.console.insert(tk.END, "    Layers' Outputsize ... OK\n")

            if not "End" in layers:
                self.console.insert(tk.END, "    Layers' Shape ... ERROR：Network has No End\n\n")
                return
            self.console.insert(tk.END, "    End of Network detected ... OK\n")
            if not self.outputSizes[-1] == Labelnum[self.v_ds.get()]:
                self.console.insert(tk.END, "    Layers' Shape ... ERROR：Network's Output must be "+str(Labelnum[self.v_ds.get()])+"\n\n")
                return
            self.console.insert(tk.END, "    Network's Output size equals dataset's Output size\n")
            self.console.insert(tk.END, "Network and Learning Setting has configured \n")

            self.console.insert(tk.END, "Constracting Network Model ... \n")
            names = [v.get() for v in self.layer_names]
            params = []
            for lp in self.layer_params:
                a = []
                for p in lp:
                    a.append(p.get())
                params.append(a)
            self.model = Model(self.v_name.get(), layers, names, params, self.v_ds.get(),
                               self.ve.get(), self.vmb.get(), self.EnableGPU.get(),
                               [self.var_addI.get(), self.var_addIn.get()], [self.var_addG.get(), self.var_addGn.get(), self.var_addGg.get()],
                               [self.var_addI2.get(), self.var_addIn2.get()], [self.var_addG2.get(), self.var_addGn2.get(), self.var_addGg2.get()])
            if not self.model.model_standby():
                self.console.insert(tk.END, "    Model Creation ... ERROR\n\n")
                return
            self.console.insert(tk.END, "Model has Created\n")

            self.buttonName.set("学習開始")
            self.console.insert(tk.END, "state = Learning Stand-by\n\n")

        elif mode == "学習開始":
            self.console.insert(tk.END, "Learning "+self.v_name.get()+" ...\n")

            self.model.train_Network()
            subprocess.Popen(['explorer',"networks\\"+self.v_name.get()])

    def switch_addI(self, event=None):
        if not self.var_addI.get():
            self.entry_addI.configure(state=tk.NORMAL)
        else:
            self.entry_addI.configure(state=tk.DISABLED)

    def switch_addG(self, event=None):
        if not self.var_addG.get():
            self.entry_addGn.configure(state=tk.NORMAL)
            self.entry_addGg.configure(state=tk.NORMAL)
        else:
            self.entry_addGn.configure(state=tk.DISABLED)
            self.entry_addGg.configure(state=tk.DISABLED)

    def switch_addI2(self, event=None):
        if not self.var_addI2.get():
            self.entry_addI2.configure(state=tk.NORMAL)
        else:
            self.entry_addI2.configure(state=tk.DISABLED)

    def switch_addG2(self, event=None):
        if not self.var_addG2.get():
            self.entry_addGn2.configure(state=tk.NORMAL)
            self.entry_addGg2.configure(state=tk.NORMAL)
        else:
            self.entry_addGn2.configure(state=tk.DISABLED)
            self.entry_addGg2.configure(state=tk.DISABLED)

if __name__ == '__main__':
    g = GUI()
    g.getRoot().mainloop()