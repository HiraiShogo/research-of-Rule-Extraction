'''
Created on 2019/06/21

@author: ail
'''

import sys
import os
import numpy as np
import chainer
import pickle

from chainer import cuda, Function, gradient_check, report, training, utils, Variable
from chainer import datasets, iterators, optimizers, serializers
from chainer.datasets import tuple_dataset, TupleDataset
from chainer import Link, Chain, ChainList
import chainer.functions as F
import chainer.links as L
from chainer import training
from chainer.training import extensions
import cupy as cp
from collections import OrderedDict

list_datasets = ("MNIST Dataset", "CIFAR-10 Dataset", "CIFAR-100 Dataset")

class Network(chainer.Chain):
    def __init__(self, layers, layerNames, layerParams):
        super(Network, self).__init__()
        self.output = {}
        self.layers = layers
        self.names = layerNames
        self.Lparams = layerParams
        self.links = []
        f = None
        for li in range(len(layers)):
            if layers[li] == "Convolution":
                f = L.Convolution2D(None,
                                   layerParams[li][0],
                                   layerParams[li][1],
                                   stride=layerParams[li][2],
                                   pad=layerParams[li][3])
                self.links +=[(self.names[li], f)]

            elif layers[li] == "Affine":
                f = L.Linear(None, layerParams[li][0])
                self.links +=[(self.names[li], f)]

            elif layers[li] == "BatchNormalization":
                f = L.BatchNormalization(layerParams[li-1][0])
                self.links +=[(self.names[li], f)]

        with self.init_scope():
            self.forward = self.links

            for link in self.links:
                self.add_link(*link)

        """
        elif layers[li] == "maxPooling":
            #self.layersF.append(F.max_pooling_2d)
            self.add_link(F.max_pooling_2d)
        elif layers[li] == "avePooling":
            #self.layersF.append(F.average_pooling_2d)
        elif layers[li] == "Sigmoid":
            #self.layersF.append(F.sigmoid)
        elif layers[li] == "ReLU":
            #self.layersF.append(F.relu)
        elif layers[li] == "Dropout":
            #self.layersF.append(F.dropout)
        """
        """
        self.conv1 = L.Convolution2D(1, 15, 5)
        self.conv2 = L.Convolution2D(15, 15, 8)
        self.conv3 = L.Convolution2D(15, 15, 16)
        self.affine1 = L.Linear(15, 15)
        self.affine2 = L.Linear(15, 10)
        """

    def __call__(self, x):
        out = x
        #print("input", out.array.shape)
        self.output = {}

        c = 0
        for name,func in self.forward:
            out = func(out)
            #self.output[name] = out.array
            #print(name, out.array.shape)
            c += 1
            for i in range(c, len(self.names)):
                if "Conv" in self.names[i] or "Affine" in self.names[i] or "B-Norm" in self.names[i]:
                    c = i
                    break
                if "m-Pool" in self.names[i]:
                    out = F.max_pooling_2d(out, self.Lparams[i][0], stride=self.Lparams[i][1], pad=self.Lparams[i][2])
                    #print(self.names[i], out.array.shape)
                elif "a-Pool" in self.names[i]:
                    out = F.average_pooling_2d(out, self.Lparams[i][0], stride=self.Lparams[i][1], pad=self.Lparams[i][2])
                elif "Dropout" in self.names[i]:
                    out = F.dropout(out, ratio=self.Lparams[i][0])
                elif "ReLU" in self.names[i]:
                    out = F.relu(out)
                elif "L_ReLU" in self.names[i]:
                    out = F.leaky_relu(x, self.Lparams[i][0])
                elif "Sigmoid" in self.names[i]:
                    out = F.sigmoid(out)
                elif "Softmax" in self.names[i]:
                    out = F.softmax(out)
                elif "End" in self.names[i]:
                    #self.output["output"] = out.array
                    return out
                #self.output[self.names[i]] = out.array
        return out

    def get_output(self, key=None):
        if key in self.output.keys():
            return self.output[key]
        return self.output


class Model:
    def __init__(self, network_name, layers, layerNames, layerParams, dataset, ep, bs, gpu, addI, addG, addI2, addG2):
        self.params = None
        self.networkName = network_name
        self.layers = layers
        self.layerNames = layerNames
        self.layerParams = layerParams
        self.path = "networks\\"+self.networkName
        self.train, self.test = None, None
        #print(len(self.train))
        try:
            self.dnn = Network(layers, layerNames, layerParams)
        except Exception as e:
            self.dnn = None
            print(e)
        self.dataset = dataset
        i = list_datasets.index(dataset)
        if i == 0:
            self.train, self.test = datasets.get_mnist(ndim=3)
        elif i == 1:
            self.train, self.test = datasets.get_cifar10()
        elif i == 2:
            self.train, self.test = datasets.get_cifar100()
        else:
            self.dnn = None
        self.addI = addI
        self.addG = addG
        self.addI2 = addI2
        self.addG2 = addG2
        self.add_Data(addI, addG, addI2, addG2)
        self.model = L.Classifier(self.dnn)
        self.frequency = -1
        self.gpu_id = 0
        self.epochs = ep
        self.batchsize = bs
        self.EnableGPU = gpu

        #print("initialize complete\n")

    def train_Network(self):
        if self.EnableGPU:
            chainer.cuda.get_device_from_id(0)  # @UndefinedVariable
            self.model.to_gpu()
        else:
            self.gpu_id = -1

        if not os.path.exists(self.path):
            os.makedirs(self.path)

        optimizer = chainer.optimizers.Adam()
        optimizer.setup(self.model)

        train_iter = chainer.iterators.SerialIterator(self.train, self.batchsize)
        test_iter = chainer.iterators.SerialIterator(self.test, self.batchsize, repeat=False, shuffle=False)

        updater = training.StandardUpdater(train_iter, optimizer, device=self.gpu_id)
        trainer = training.Trainer(updater, (self.epochs, 'epoch'), out=self.path)

        trainer.extend(extensions.Evaluator(test_iter, self.model,device=self.gpu_id))
        trainer.extend(extensions.dump_graph('main/loss'))

        frequency = self.epochs if self.frequency == -1 else max(1, self.frequency)
        trainer.extend(extensions.snapshot(), trigger=(frequency, 'epoch'))
        trainer.extend(extensions.LogReport(log_name="Learn_Log.txt"))
        trainer.extend(
            extensions.PlotReport(['main/loss', 'validation/main/loss'],
                                  'epoch', file_name='loss.png'))
        trainer.extend(
            extensions.PlotReport(['main/accuracy', 'validation/main/accuracy'],
                                  'epoch', file_name='accuracy.png'))
        trainer.extend(extensions.PrintReport(
            ['epoch', 'main/loss', 'validation/main/loss',
             'main/accuracy', 'validation/main/accuracy', 'elapsed_time']))
        trainer.run()

        self.save_Network()

    def add_Data(self, addI, addG, addI2, addG2):
        tr = []
        te = []
        atr = []
        ate = []
        for d in self.train:
            img = d[0]
            ans = d[1]
            tr.append(img)
            atr.append(ans)

        for d in self.test:
            img = d[0]
            ans = d[1]
            te.append(img)
            ate.append(ans)

        if addI[0]:
            n = addI[1]
            if n <= len(self.train):
                d = self.train[:n]
                for i in range(len(d)):
                    img = d[i][0]
                    ans = d[i][1]
                    img = img[:][:][::-1]
                    tr.append(img)
                    atr.append(ans)

        if addG[0]:
            n = addG[1]
            g = addG[2]
            if n <= len(self.train):
                d = self.train[:n]
                for i in range(len(d)):
                    img = d[i][0]
                    ans = d[i][1]
                    img = img**(1/g)
                    tr.append(img)
                    atr.append(ans)

        if addI2[0]:
            n = addI2[1]
            if n <= len(self.train):
                d = self.test[:n]
                for i in range(len(d)):
                    img = d[i][0]
                    ans = d[i][1]
                    img = img[:][:][::-1]
                    te.append(img)
                    ate.append(ans)

        if addG2[0]:
            n = addG2[1]
            g = addG2[2]
            if n <= len(self.train):
                d = self.test[:n]
                for i in range(len(d)):
                    img = d[i][0]
                    ans = d[i][1]
                    img = img**(1/g)
                    te.append(img)
                    ate.append(ans)

        self.train = TupleDataset(tr, atr)
        self.test = TupleDataset(te, ate)

    def save_Network(self):
        with open(self.path+"\\Constract.pkl", 'wb') as f:
            pickle.dump({"dataset":self.dataset,
                          "layers":self.layers,
                          "names":self.layerNames,
                          "params":self.layerParams,
                          "addI":self.addI,
                          "addG":self.addG,
                          "addI2":self.addI2,
                          "addG2":self.addG2}, f)
        serializers.save_npz(self.path+'\\network.npz', self.model)

    def model_standby(self):
        return self.dnn != None

    def load_Network(self,path =""):
        serializers.load_npz(path, self.model)

    def predict_Test(self, num, gpu=True, key=[]):
        #print(np.array(self.test[0]).shape)
        prediction = self.model.predictor(np.array(self.test[num][0][0]).reshape(1, 1, 28, 28))
        probability = F.softmax(prediction).data[0]
        np.set_printoptions(precision=20, floatmode='fixed', suppress=True)
        ans = self.dnn.get_output()
        ans["output"] = probability
        if len(key) == 0:
            return ans
        a = {}
        for k in key:
            a[k] = ans[k]
        #a["output"] = ans["output"]
        return a

        #print(probability)
        #print(self.dnn.get_output())
        #return ans

    def predict_Train(self, num, gpu=True, key=[]):
        #print(np.array(self.test[0]).shape)
        prediction = self.model.predictor(np.array(self.train[num][0][0]).reshape(1, 1, 28, 28))
        probability = F.softmax(prediction).data[0]
        np.set_printoptions(precision=20, floatmode='fixed', suppress=True)
        ans = self.dnn.get_output()
        ans["output"] = probability
        if len(key) == 0:
            return ans
        a = {}
        for k in key:
            a[k] = ans[k]
        #a["output"] = ans["output"]
        return a
        #print(probability)
        #print(self.dnn.get_output())
        #return ans