import numpy as np
import cupy as cp
import os
from multiprocessing import Pool
import time
from PIL import Image
import chainer

list_datasets = ("MNIST Dataset", "CIFAR-10 Dataset", "CIFAR-100 Dataset")

def unwrap(arg, **kwarg):
    # メソッドfをクラスメソッドとして呼び出す関数
    return Image_Extract.get_Input(*arg, **kwarg)

def unwrap2(arg, **kwarg):
    # メソッドfをクラスメソッドとして呼び出す関数
    return get_Input2(*arg, **kwarg)

def get_Input2(x, gpu, d):
    mat = None
    if gpu:
        mat = cp
    else:
        mat = np
    size = x.shape
    inputdata = mat.array([])
    for ix in range(size[0]):
        for iy in range(size[1]):
            for iz in range(size[2]):
                x_d = x.copy()
                x_d[ix, iy, iz] += d
                if len(inputdata) == 0:
                    inputdata = mat.array([x_d], dtype=mat.float32)
                else:
                    s = x_d.shape
                    inputdata = mat.concatenate([inputdata, x_d.reshape(1, s[0], s[1], s[2])], axis=0)
    if gpu:
        return chainer.cuda.to_cpu(inputdata)
    else:
        return inputdata

class Image_Extract:
    def __init__(self, model, dataset, d, key, path, gpu, ac, sp, bs=500):
        self.d = d
        self.model = model
        self.dataset = dataset
        self.key = key
        self.path = path+"\\Imaegs"
        self.path1 = self.path+"\\normal"
        self.path2 = self.path+"\\zoom"
        if not os.path.exists(self.path):
            os.makedirs(self.path1)
            os.makedirs(self.path2)
        self.ac = ac
        self.sp = sp
        self.gpu = gpu
        self.bs = bs
        if gpu:
            self.mat = cp
        else:
            self.mat = np

    def smoothGrad(self, x, y):
        diffs = []
        s =  x.shape
        datasize = s[1]*s[2]*s[3]
        mask = self.mat.zeros((datasize, s[1], s[2], s[3]))
        for i in range(datasize):
            d1 = i // (s[2]*s[3])
            d2 = (i - d1*(s[2]*s[3])) // s[3]
            d3 = (i - d1*(s[2]*s[3])) % s[3]
            mask[i,d1,d2,d3] += self.d

        x2 = x.copy().reshape(s[0], 1, s[1], s[2], s[3])

        #inputs = p.map(get_Input2, [[i, self.mat, self.d] for i in x])
        self.ac("  Differencials Culculating...")
        for i in range(len(x2)):
            input = x2[i]+mask
            input = input.astype(self.mat.float32, copy=False)
            if i == 0:
                diffs = self.model.predict_X(input, key=[self.key])[self.key]
            else:
                diffs += self.model.predict_X(input, key=[self.key])[self.key]
            self.sp(i+1)

        diffs = (diffs - y) / self.d
        self.ac("OK\n")


        self.ac("  Reshaping Differencials...")
        diffs = self.mat.transpose(diffs, axes=(1, 2, 3, 0))
        if list_datasets.index(self.dataset) == 1 or list_datasets.index(self.dataset) == 2:
            diffs = diffs.reshape(-1, 3, int(diffs.shape[-1]/3))
        else:
            diffs = diffs.reshape(-1, diffs.shape[-1])
        self.ac("OK\n")

        self.ac("  Normalizing...")
        diffs = self.normalization(diffs)
        self.ac("OK\n")

        self.ac("  Saving Images...")
        self.saveImage(diffs)
        self.ac("OK\n")

        return diffs

    def get_Input(self, x):
        size = x.shape
        inputdata = self.mat.array([])
        for ix in range(size[0]):
            for iy in range(size[1]):
                for iz in range(size[2]):
                    x_d = x.copy()
                    x_d[ix, iy, iz] += self.d
                    if len(inputdata) == 0:
                        inputdata = self.mat.array([x_d], dtype=self.mat.float32)
                    else:
                        s = x_d.shape
                        inputdata = self.mat.concatenate([inputdata, x_d.reshape(1, s[0], s[1], s[2])], axis=0)
        return inputdata

    def normalization(self, image):
        max = self.mat.max(image, axis=len(image.shape)-1)
        min = self.mat.min(image, axis=len(image.shape)-1)

        if list_datasets.index(self.dataset) == 1 or list_datasets.index(self.dataset) == 2:
            max = max.reshape(-1, 3, 1)
            min = min.reshape(-1, 3, 1)
        else:
            max = max.reshape(-1, 1)
            min = min.reshape(-1, 1)

        return (image - min) / (max - min)

    def saveImage(self, images):
        if self.gpu:
            images = self.mat.asnumpy(images)
        for i in range(len(images)):
            if list_datasets.index(self.dataset) == 0:
                image = images[i].reshape((28,28)) * 255
                im = Image.fromarray(image.astype(np.uint8))
                im.convert("L").save(self.path1+"\\unit-"+str(i)+".jpg")
                im.resize((200,200)).save(self.path2+"\\unit-"+str(i)+".jpg")
            elif list_datasets.index(self.dataset) == 1 or list_datasets.index(self.dataset) == 2:
                image = images[i].reshape((3,32,32)).transpose(1,2,0) * 255
                im = Image.fromarray(image.astype(np.uint8))
                im.convert("RGB").save(self.path1+"\\unit-"+str(i)+".jpg")
                im.resize((200,200)).save(self.path2+"\\unit-"+str(i)+".jpg")
