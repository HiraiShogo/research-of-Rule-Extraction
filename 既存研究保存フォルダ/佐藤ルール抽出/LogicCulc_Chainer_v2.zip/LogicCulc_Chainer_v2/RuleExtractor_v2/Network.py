'''
Created on 2019/06/21

@author: ail
'''

import sys
import os
import numpy as np
import chainer
import pickle
import time

from chainer import cuda, Function, gradient_check, report, training, utils, Variable
from chainer import datasets, iterators, optimizers, serializers
from chainer.datasets import tuple_dataset, TupleDataset
from chainer import Link, Chain, ChainList
import chainer.functions as F
import chainer.links as L
from chainer import training
from chainer.training import extensions
import cupy as cp
from collections import OrderedDict

from tkinter import filedialog

list_datasets = ("MNIST Dataset", "CIFAR-10 Dataset", "CIFAR-100 Dataset")

class Network(chainer.Chain):
    def __init__(self, layers, layerNames, layerParams):
        super(Network, self).__init__()
        self.output = {}
        self.layers = layers
        self.names = layerNames
        self.Lparams = layerParams
        self.links = []
        self.key = []
        f = None
        for li in range(len(layers)):
            if layers[li] == "Convolution":
                f = L.Convolution2D(None,
                                   layerParams[li][0],
                                   layerParams[li][1],
                                   stride=layerParams[li][2],
                                   pad=layerParams[li][3])
                self.links +=[(self.names[li], f)]

            elif layers[li] == "Affine":
                f = L.Linear(None, layerParams[li][0])
                self.links +=[(self.names[li], f)]

            elif layers[li] == "BatchNormalization":
                f = L.BatchNormalization(layerParams[li-1][0])
                self.links +=[(self.names[li], f)]

        with self.init_scope():
            self.forward = self.links

            for link in self.links:
                self.add_link(*link)

        """
        elif layers[li] == "maxPooling":
            #self.layersF.append(F.max_pooling_2d)
            self.add_link(F.max_pooling_2d)
        elif layers[li] == "avePooling":
            #self.layersF.append(F.average_pooling_2d)
        elif layers[li] == "Sigmoid":
            #self.layersF.append(F.sigmoid)
        elif layers[li] == "ReLU":
            #self.layersF.append(F.relu)
        elif layers[li] == "Dropout":
            #self.layersF.append(F.dropout)
        """
        """
        self.conv1 = L.Convolution2D(1, 15, 5)
        self.conv2 = L.Convolution2D(15, 15, 8)
        self.conv3 = L.Convolution2D(15, 15, 16)
        self.affine1 = L.Linear(15, 15)
        self.affine2 = L.Linear(15, 10)
        """

    def __call__(self, x):
        out = x
        #print("input", out.array.shape)
        self.output = {}

        c = 0
        for name,func in self.forward:
            out = func(out)
            if name in self.key or len(self.key) == 0:
                self.output[name] = out.array
            #print(name, out.array.shape)
            c += 1
            for i in range(c, len(self.names)):
                if "Conv" in self.names[i] or "Affine" in self.names[i] or "B-Norm" in self.names[i]:
                    c = i
                    break
                if "m-Pool" in self.names[i]:
                    out = F.max_pooling_2d(out, self.Lparams[i][0], stride=self.Lparams[i][1], pad=self.Lparams[i][2])
                    #print(self.names[i], out.array.shape)
                elif "a-Pool" in self.names[i]:
                    out = F.average_pooling_2d(out, self.Lparams[i][0], stride=self.Lparams[i][1], pad=self.Lparams[i][2])
                elif "Dropout" in self.names[i]:
                    #out = F.dropout(out, ratio=self.Lparams[i][0])
                    pass
                elif "ReLU" in self.names[i]:
                    out = F.relu(out)
                elif "L_ReLU" in self.names[i]:
                    out = F.leaky_relu(x, self.Lparams[i][0])
                elif "Sigmoid" in self.names[i]:
                    out = F.sigmoid(out)
                elif "Softmax" in self.names[i]:
                    out = F.softmax(out)
                elif "End" in self.names[i]:
                    if "output" in self.key or len(self.key) == 0:
                        self.output["output"] = out.array
                    return out
                if self.names[i] in self.key or len(self.key) == 0:
                    self.output[self.names[i]] = out.array
        return out

    def setKey(self, key):
        self.key = key

    def get_output(self):
        """
        if key in self.output.keys():
            return self.output[key]
        """
        return self.output


class Model:
    def __init__(self, dataset, layers, layerNames, layerParams, addI, addG, addI2, addG2, network_name="", ep=None, bs=None, gpu=False, batchsize=5000):
        self.params = None
        self.networkName = network_name
        self.layers = layers
        self.layerNames = layerNames
        self.layerParams = layerParams
        self.path = "networks\\"+self.networkName
        #print(len(self.train))
        try:
            self.dnn = Network(layers, layerNames, layerParams)
        except Exception as e:
            self.dnn = None
            print(e)
        self.dataset = dataset
        i = list_datasets.index(dataset)
        self.size = []
        if i == 0:
            self.train, self.test = datasets.get_mnist(ndim=3)
            self.size = self.train[0][0].shape
        elif i == 1:
            self.train, self.test = datasets.get_cifar10()
            self.size = self.train[0][0].shape
        elif i == 2:
            self.train, self.test = datasets.get_cifar100()
            self.size = self.train[0][0].shape
        else:
            self.dnn = None
        self.add_Data(addI, addG, addI2, addG2)
        self.train_NL = np.asarray([self.train[i][0] for i in range(len(self.train))])
        self.test_NL = np.asarray([self.test[i][0] for i in range(len(self.test))])
        self.model = L.Classifier(self.dnn)
        self.frequency = -1
        self.gpu_id = 0
        self.epochs = ep
        self.batchsize = bs
        self.mat = 0
        self.EnableGPU = gpu
        if gpu:
            self.mat = cp
        else:
            self.mat = np
        self.bs = batchsize
        chainer.using_config('train', False)
        #print("initialize complete\n")

    def train_Network(self):
        if self.EnableGPU:
            chainer.cuda.get_device_from_id(0)  # @UndefinedVariable
            self.model.to_gpu()
        else:
            self.gpu_id = -1

        if not os.path.exists(self.path):
            os.makedirs(self.path)

        optimizer = chainer.optimizers.Adam()
        optimizer.setup(self.model)

        train_iter = chainer.iterators.SerialIterator(self.train, self.batchsize)
        test_iter = chainer.iterators.SerialIterator(self.test, self.batchsize, repeat=False, shuffle=False)

        updater = training.StandardUpdater(train_iter, optimizer, device=self.gpu_id)
        trainer = training.Trainer(updater, (self.epochs, 'epoch'), out=self.path)

        trainer.extend(extensions.Evaluator(test_iter, self.model,device=self.gpu_id))
        trainer.extend(extensions.dump_graph('main/loss'))

        frequency = self.epochs if self.frequency == -1 else max(1, self.frequency)
        trainer.extend(extensions.snapshot(), trigger=(frequency, 'epoch'))
        trainer.extend(extensions.LogReport(log_name="Learn_Log.txt"))
        trainer.extend(
            extensions.PlotReport(['main/loss', 'validation/main/loss'],
                                  'epoch', file_name='loss.png'))
        trainer.extend(
            extensions.PlotReport(['main/accuracy', 'validation/main/accuracy'],
                                  'epoch', file_name='accuracy.png'))
        trainer.extend(extensions.PrintReport(
            ['epoch', 'main/loss', 'validation/main/loss',
             'main/accuracy', 'validation/main/accuracy', 'elapsed_time']))
        trainer.run()

        self.save_Network()

    def add_Data(self, addI, addG, addI2, addG2):
        tr = []
        te = []
        atr = []
        ate = []
        for d in self.train:
            img = d[0]
            ans = d[1]
            tr.append(img)
            atr.append(ans)

        for d in self.test:
            img = d[0]
            ans = d[1]
            te.append(img)
            ate.append(ans)

        if addI[0]:
            n = addI[1]
            if n <= len(self.train):
                d = self.train[:n]
                for i in range(len(d)):
                    img = d[i][0]
                    ans = d[i][1]
                    img = img[:][:][::-1]
                    tr.append(img)
                    atr.append(ans)

        if addG[0]:
            n = addG[1]
            g = addG[2]
            if n <= len(self.train):
                d = self.train[:n]
                for i in range(len(d)):
                    img = d[i][0]
                    ans = d[i][1]
                    img = img**(1/g)
                    tr.append(img)
                    atr.append(ans)

        if addI2[0]:
            n = addI2[1]
            if n <= len(self.train):
                d = self.test[:n]
                for i in range(len(d)):
                    img = d[i][0]
                    ans = d[i][1]
                    img = img[:][:][::-1]
                    te.append(img)
                    ate.append(ans)

        if addG2[0]:
            n = addG2[1]
            g = addG2[2]
            if n <= len(self.train):
                d = self.test[:n]
                for i in range(len(d)):
                    img = d[i][0]
                    ans = d[i][1]
                    img = img**(1/g)
                    te.append(img)
                    ate.append(ans)

        self.train = TupleDataset(tr, atr)
        self.test = TupleDataset(te, ate)

    def save_Network(self):
        with open(self.path+"\\Constract.pkl", 'wb') as f:
            pickle.dump({"layers":self.layers,
                          "names":self.layerNames,
                          "params":self.layerParams}, f)
        serializers.save_npz(self.path+'\\network.npz', self.model)

    def model_standby(self):
        return self.dnn != None

    def load_Network(self,path =""):
        if path != "":
            serializers.load_npz(path, self.model)
        else:
            typ = [('ネットワーク構成ファイル','*.npz')]
            dir = 'networks\\'
            fle = filedialog.askopenfilename(filetypes = typ, initialdir = dir)

    def toGPU(self):
        if self.EnableGPU:
            chainer.cuda.get_device_from_id(0)  # @UndefinedVariable
            self.model.to_gpu()

    def predict_Test(self, num, key=[]):
        #print(np.array(self.test[0]).shape)
        self.dnn.setKey(key)
        prediction = self.model.predictor(self.mat.array(self.test[num][0]).reshape(1, self.size[0], self.size[1], self.size[2]))
        return self.dnn.get_output()

    def predict_Tests(self, num=-1, key=[]):
        self.dnn.setKey(key)
        inputdata = []
        output = {}
        for k in key:
            output[k] = []
        if num == -1:
            for iter in range(len(self.test)//self.bs):
                inputdata = self.mat.asarray(self.test_NL[iter*self.bs:(iter+1)*self.bs])
                prediction = self.model.predictor(inputdata)
                output_DNN = self.dnn.get_output()
                for k, v in output_DNN.items():
                    if iter == 0:
                        output[k] = v
                    else:
                        output[k] = self.mat.concatenate([output[k], v], axis=0)

            if len(self.test) % self.bs != 0:
                inputdata = self.mat.asarray(self.test_NL[len(self.test_NL)//self.bs:])
                prediction = self.model.predictor(inputdata)
                output_DNN = self.dnn.get_output()
                for k, v in output_DNN.items():
                    if output[k] == []:
                        output[k] = v
                    else:
                        output[k] = self.mat.concatenate([output[k], v], axis=0)

        elif num > self.bs:
            for iter in range(num//self.bs):
                inputdata = self.mat.asarray(self.test_NL[iter*self.bs:(iter+1)*self.bs])
                prediction = self.model.predictor(inputdata)
                output_DNN = self.dnn.get_output()
                for k, v in output_DNN.items():
                    if iter == 0:
                        output[k] = v
                    else:
                        output[k] = self.mat.concatenate([output[k], v], axis=0)

            if num % self.bs != 0:
                inputdata = self.mat.asarray(self.test_NL[num//self.bs:])
                prediction = self.model.predictor(inputdata)
                output_DNN = self.dnn.get_output()
                for k, v in output_DNN.items():
                    if output[k] == []:
                        output[k] = v
                    else:
                        output[k] = self.mat.concatenate([output[k], v], axis=0)

        else:
            prediction = self.model.predictor(self.mat.asarray(self.test_NL[:num]))
            output_DNN = self.dnn.get_output()
            for k, v in output_DNN.items():
                if output[k] == []:
                    output[k] = v
                else:
                    output[k] = self.mat.concatenate([output[k], v], axis=0)
        return output

    def predict_Train(self, num, key=[]):
        #print(np.array(self.test[0]).shape)
        self.dnn.setKey(key)
        prediction = self.model.predictor(self.mat.array(self.train[num][0]).reshape(1, self.size[0], self.size[1], self.size[2]))
        return self.dnn.get_output()

    def predict_Trains(self, num=-1, key=[]):
        #print(np.array(self.test[0]).shape)
        self.dnn.setKey(key)
        inputdata = []
        output = {}
        for k in key:
            output[k] = []
        if num == -1:
            for iter in range(len(self.train)//self.bs):
                inputdata = self.mat.asarray(self.train_NL[iter*self.bs:(iter+1)*self.bs])
                prediction = self.model.predictor(inputdata)
                output_DNN = self.dnn.get_output()
                for k, v in output_DNN.items():
                    if iter == 0:
                        output[k] = v
                    else:
                        output[k] = self.mat.concatenate([output[k], v], axis=0)

            if len(self.train) % self.bs != 0:
                inputdata = self.mat.asarray(self.train_NL[len(self.train_NL)//self.bs:])
                prediction = self.model.predictor(inputdata)
                output_DNN = self.dnn.get_output()
                for k, v in output_DNN.items():
                    if output[k] == []:
                        output[k] = v
                    else:
                        output[k] = self.mat.concatenate([output[k], v], axis=0)
        elif num > self.bs:
            for iter in range(num//self.bs):
                inputdata = self.mat.asarray(self.train_NL[iter*self.bs:(iter+1)*self.bs])
                prediction = self.model.predictor(inputdata)
                output_DNN = self.dnn.get_output()
                for k, v in output_DNN.items():
                    if iter == 0:
                        output[k] = v
                    else:
                        output[k] = self.mat.concatenate([output[k], v], axis=0)

            if num % self.bs != 0:
                inputdata = self.mat.asarray(self.train_NL[num//self.bs:])
                prediction = self.model.predictor(inputdata)
                output_DNN = self.dnn.get_output()
                for k, v in output_DNN.items():
                    if output[k] == []:
                        output[k] = v
                    else:
                        output[k] = self.mat.concatenate([output[k], v], axis=0)

        else:
            prediction = self.model.predictor(self.mat.asarray(self.train_NL[:num]))
            output_DNN = self.dnn.get_output()
            for k, v in output_DNN.items():
                if output[k] == []:
                    output[k] = v
                else:
                    output[k] = self.mat.concatenate([output[k], v], axis=0)
        return output

    def getTrain(self, num):
        return self.train[num][0]

    def getTrains(self, num=-1):
        if num == -1:
            return self.train
        else:
            return self.train[:num][0]

    def getTests(self, num=-1):
        if num == -1:
            return self.test
        else:
            return self.test[:num][0]

    def predict_X(self, x, key=[]):
        self.dnn.setKey(key)
        inputdata = []
        output = {}
        for k in key:
            output[k] = []
        if len(x) > self.bs:
            for iter in range(len(x)//self.bs):
                inputdata = x[iter*self.bs:(iter+1)*self.bs]
                prediction = self.model.predictor(inputdata)
                output_DNN = self.dnn.get_output()
                for k, v in output_DNN.items():
                    if iter == 0:
                        output[k] = v
                    else:
                        output[k] = self.mat.concatenate([output[k], v], axis=0)

            if len(x) % self.bs != 0:
                inputdata = x[len(x)//self.bs:]
                prediction = self.model.predictor(inputdata)
                output_DNN = self.dnn.get_output()
                for k, v in output_DNN.items():
                    if output[k] == []:
                        output[k] = v
                    else:
                        output[k] = self.mat.concatenate([output[k], v], axis=0)
        else:
            prediction = self.model.predictor(x)
            output = self.dnn.get_output()
        return output