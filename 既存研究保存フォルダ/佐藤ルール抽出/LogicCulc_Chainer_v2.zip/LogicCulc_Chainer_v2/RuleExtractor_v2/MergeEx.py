from PIL import Image
import os
import numpy as np
import cupy as cp

list_datasets = ("MNIST Dataset", "CIFAR-10 Dataset", "CIFAR-100 Dataset")

class MergeExecutor:
    def __init__(self, dataset, path, pr, ac, gpu):
        self.path = path + "\\Merge"
        self.path1 = self.path+"\\normal"
        self.path2 = self.path+"\\zoom"
        if not os.path.exists(self.path):
            os.makedirs(self.path)
        if not os.path.exists(self.path1):
            os.makedirs(self.path1)
        if not os.path.exists(self.path2):
            os.makedirs(self.path2)
        self.pr = pr
        self.ac = ac
        self.M_image = []
        self.dataset = dataset
        self.gpu = gpu
        if gpu:
            self.mat = cp
        else:
            self.mat = np

    def merge(self, rule, image):
        inv_image = 1 - image
        for r in range(len(rule)):
            mi2 = []
            for s in rule[r]:
                mi1 = None
                for sn in range(len(s[0])):
                    arr = s[0][sn] * image[sn] +abs(1 - s[0][sn]) * inv_image[sn]
                    if sn == 0:
                        mi1 = arr
                    else:
                        mi1 = self.mat.minimum(mi1, arr)
                if len(mi2) == 0:
                    mi2 = mi1
                else:
                    mi2 = self.mat.maximum(mi2, mi1)
            self.M_image.append(mi2)

    def normalization(self, image):
        max = self.mat.max(image, axis=1).reshape(-1, 1)
        min = self.mat.min(image, axis=1).reshape(-1, 1)

        return (image - min) / (max - min)

    def saveImage(self):
        for i in range(len(self.M_image)):
            if list_datasets.index(self.dataset) == 0:
                image = self.normalization(self.M_image[i].reshape(1,-1))
                if self.gpu:
                    image = self.mat.asnumpy(image[i])
                image = image.reshape((28,28)) * 255
                im = Image.fromarray(image.astype(np.uint8))
                im.convert("L").save(self.path1+"\\output-"+str(i)+".jpg")
                im.resize((200,200)).save(self.path2+"\\output-"+str(i)+".jpg")
            elif list_datasets.index(self.dataset) == 1 or list_datasets.index(self.dataset) == 2:
                image = self.normalization(self.M_image[i].reshape(3,-1))
                if self.gpu:
                    image = self.mat.asnumpy(image)
                image = image.reshape((3,32,32)).transpose(1,2,0) * 255
                im = Image.fromarray(image.astype(np.uint8))
                im.convert("RGB").save(self.path1+"\\output-"+str(i)+".jpg")
                im.resize((200,200)).save(self.path2+"\\output-"+str(i)+".jpg")