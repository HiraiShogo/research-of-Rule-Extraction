#Chainer
from chainer import cuda, Function, gradient_check, report, training, utils, Variable
from chainer import datasets, iterators, optimizers, serializers
from chainer.datasets import tuple_dataset
from chainer import Link, Chain, ChainList
import chainer.functions as F
import chainer.links as L
from chainer import training
from chainer.training import extensions
import chainer

#tkinter
import tkinter as tk
import tkinter.ttk as ttk
import tkinter.font as font
import tkinter.scrolledtext as sc
from tkinter import filedialog

#その他
from Network import Network, Model  # @UnresolvedImport
from Executor import Executor  # @UnresolvedImport
import pickle
import os

list_datasets = ("MNIST Dataset", "CIFAR-10 Dataset", "CIFAR-100 Dataset")
Labelnum = {"MNIST Dataset":10, "CIFAR-10 Dataset":10, "CIFAR-100 Dataset":100}
DataNum = {"MNIST Dataset":(60000, 10000), "CIFAR-10 Dataset":(50000, 10000), "CIFAR-100 Dataset":(50000, 10000)}
Labels = [["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
          ["airplane", "automobile", "bird", "cat", "deer", "dog", "frog", "horse", "ship", "truck"],
          []]

class UI:
    def __init__(self):
        font1 = ("", 12)
        font2 = ("", 15, "bold")

        self.root = tk.Tk()
        self.root.title("Rule Extractor")
        self.root.geometry("700x800")

        self.frame_main = tk.Frame(self.root)
        self.frame_main.pack(fill="both", padx=10, pady=10)

        frameName = tk.Frame(self.frame_main)
        frameName.pack(fill="x", pady=3)
        labelName = tk.Label(frameName, text="保存名：", font=font1)
        labelName.grid(row=0, column=0, padx=2)
        self.v_name = tk.StringVar()
        self.v_name.set("ネットワーク1")
        entryName = tk.Entry(frameName, textvariable=self.v_name, font=font1)
        entryName.grid(row=0, column=1, padx=2)

        frameNet = tk.LabelFrame(self.frame_main, text="設定", font=font1, relief=tk.GROOVE, borderwidth = 4)
        frameNet.pack(fill="x", pady=3)
        buttonRef = tk.Button(frameNet, text="ネットワーク読込", font=font1)
        buttonRef.bind("<Button-1>", self.readNetwork)
        buttonRef.grid(row=0, column=0, padx=2, pady=3)
        self.layers = []
        self.names = ["No Network"]
        self.params = []

        labelDSA = tk.Label(frameNet, text="データセット：", font=font2)
        labelDSA.grid(row=1, column=0, padx=2, pady=4)
        self.v_ds = tk.StringVar()
        self.v_ds.set("ー")
        labelDSB = tk.Label(frameNet, textvariable=self.v_ds, font=font2)
        labelDSB.grid(row=1, column=1, padx=2, pady=4, sticky=tk.W)

        self.l_b1 = tk.Label(frameNet, text="input", font=("", 15))
        self.l_b1.grid(row=2, column=0, padx=2)

        labelA = tk.Label(frameNet, text="ー\n|\n|\n|\n|\n|\n|\n|\nー", font=font1)
        labelA.grid(row=3, column=0, padx=2, pady=2)

        self.v_b = tk.StringVar()
        self.v_b.set(self.names[0])
        self.cb_b = ttk.Combobox(frameNet, textvariable=self.v_b, width=18, font=font.Font(self.root, family="",size=12))
        self.cb_b['values'] = self.names
        self.cb_b.grid(row=4, column=0, columnspan=6, padx=2, sticky=tk.W)

        labelB = tk.Label(frameNet, text="ー\n|\n|\n|\n|\n|\n|\n|\nー", font=font1)
        labelB.grid(row=5, column=0, padx=2, pady=2)

        self.l_b2 = tk.Label(frameNet, text="output", font=("", 15))
        self.l_b2.grid(row=6, column=0, padx=2)

        frameSG = tk.LabelFrame(frameNet, text="SmoothGrad設定", font=font1, relief=tk.GROOVE, borderwidth = 3)
        frameSG.grid(row=3, column=1, columnspan=2, padx=5)
        self.stateSG = tk.BooleanVar()
        self.stateSG.set(True)
        buttonSG = tk.Checkbutton(frameSG, text="SmoothGrad実行", variable=self.stateSG, font=font1)
        buttonSG.grid(row=0, column=0, padx=5, pady=2)
        buttonSG.bind("<Button-1>", self.mergeSwitchSG)
        self.v_na = tk.DoubleVar()
        self.v_na.set(0.0)
        self.v_ns = tk.DoubleVar()
        self.v_ns.set(0.1)
        self.v_numSG = tk.IntVar()
        self.v_numSG.set(DataNum[list_datasets[0]][0])
        self.addI = tk.BooleanVar()
        self.addI.set(True)
        self.addG = tk.BooleanVar()
        self.addG.set(True)
        self.addIn = tk.IntVar()
        self.addIn.set(DataNum[list_datasets[0]][0])
        self.addGn = tk.IntVar()
        self.addGn.set(DataNum[list_datasets[0]][0])
        self.addGg = tk.DoubleVar()
        self.addGg.set(1.5)
        self.v_d = tk.DoubleVar()
        self.v_d.set(0.004)
        self.labelNA = tk.Label(frameSG, text="正規分布.平均 = ", font=font1)
        self.labelNA.grid(row=1, column=0, padx=2, pady=2)
        self.entryNA = tk.Entry(frameSG, width=10, textvariable=self.v_na, font=font1)
        self.entryNA.grid(row=1, column=1, padx=2, pady=2)
        self.labelNS = tk.Label(frameSG, text="正規分布.標準偏差 = ", font=font1)
        self.labelNS.grid(row=2, column=0, padx=2, pady=2)
        self.entryNS = tk.Entry(frameSG, width=10, textvariable=self.v_ns, font=font1)
        self.entryNS.grid(row=2, column=1, padx=2, pady=2)
        self.labelNum = tk.Label(frameSG, text="使用データ数 = ", font=font1)
        self.labelNum.grid(row=3, column=0, padx=2, pady=2)
        self.entryNum = tk.Entry(frameSG, width=10, textvariable=self.v_numSG, font=font1)
        self.entryNum.grid(row=3, column=1, padx=2, pady=2)
        self.labelAI = tk.Checkbutton(frameSG, variable=self.addI, text="左右反転", font=font1)
        self.labelAI.grid(row=4, column=0, padx=2, pady=2)
        self.labelAI2 = tk.Label(frameSG, text="データ数：", font=font1)
        self.labelAI2.grid(row=4, column=1, padx=2, pady=2)
        self.entryAI = tk.Entry(frameSG, width=10, textvariable=self.addIn, font=font1)
        self.entryAI.grid(row=4, column=2, padx=2, pady=2)
        self.labelAG = tk.Checkbutton(frameSG, variable=self.addG, text="ガンマ変換", font=font1)
        self.labelAG.grid(row=5, column=0, padx=2, pady=2)
        self.labelAG2 = tk.Label(frameSG, text="データ数：", font=font1)
        self.labelAG2.grid(row=5, column=1, padx=2, pady=2)
        self.entryAGn = tk.Entry(frameSG, width=10, textvariable=self.addGn, font=font1)
        self.entryAGn.grid(row=5, column=2, padx=2, pady=2)
        self.labelAG3 = tk.Label(frameSG, text="γ = ", font=font1)
        self.labelAG3.grid(row=5, column=3, padx=2, pady=2)
        self.entryAGg = tk.Entry(frameSG, width=10, textvariable=self.addGg, font=font1)
        self.entryAGg.grid(row=5, column=4, padx=2, pady=2)
        self.labelD = tk.Label(frameSG, text="偏微分.微小値 = ", font=font1)
        self.labelD.grid(row=6, column=0, padx=2, pady=2)
        self.entryD = tk.Entry(frameSG, width=10, textvariable=self.v_d, font=font1)
        self.entryD.grid(row=6, column=1, padx=2, pady=2)

        frameREx = tk.LabelFrame(frameNet, text="ルール抽出設定", font=font1, relief=tk.GROOVE, borderwidth = 3)
        frameREx.grid(row=5, column=1, columnspan=2, padx=2, pady=2)
        self.stateREx = tk.BooleanVar()
        self.stateREx.set(True)
        buttonREx = tk.Checkbutton(frameREx, text="ルール抽出実行", variable=self.stateREx, font=font1)
        buttonREx.grid(row=0, column=0, padx=2, pady=2)
        buttonREx.bind("<Button-1>", self.mergeSwitchR)
        self.v_numRExE = tk.IntVar()
        self.v_numRExE.set(DataNum[list_datasets[0]][0])
        self.v_numRExT = tk.IntVar()
        self.v_numRExT.set(DataNum[list_datasets[0]][1])
        self.addIR = tk.BooleanVar()
        self.addIR.set(True)
        self.addGR = tk.BooleanVar()
        self.addGR.set(True)
        self.addInR = tk.IntVar()
        self.addInR.set(DataNum[list_datasets[0]][0])
        self.addGnR = tk.IntVar()
        self.addGnR.set(DataNum[list_datasets[0]][0])
        self.addGgR = tk.DoubleVar()
        self.addGgR.set(1.5)
        self.addI2R = tk.BooleanVar()
        self.addI2R.set(True)
        self.addG2R = tk.BooleanVar()
        self.addG2R.set(True)
        self.addIn2R = tk.IntVar()
        self.addIn2R.set(DataNum[list_datasets[0]][1])
        self.addGn2R = tk.IntVar()
        self.addGn2R.set(DataNum[list_datasets[0]][1])
        self.addGg2R = tk.DoubleVar()
        self.addGg2R.set(1.5)
        self.labelRExE = tk.Label(frameREx, text="抽出用データ数 = ", font=font1)
        self.labelRExE.grid(row=1, column=0, padx=2, pady=2)
        self.entryRExE = tk.Entry(frameREx, width=10, textvariable=self.v_numRExE, font=font1)
        self.entryRExE.grid(row=1, column=1, padx=2, pady=2)
        self.labelAIRl = tk.Checkbutton(frameREx, variable=self.addIR, text="左右反転", font=font1)
        self.labelAIRl.grid(row=2, column=0, padx=2, pady=2)
        self.labelAI2Rl = tk.Label(frameREx, text="データ数：", font=font1)
        self.labelAI2Rl.grid(row=2, column=1, padx=2, pady=2)
        self.entryAIRl = tk.Entry(frameREx, width=10, textvariable=self.addInR, font=font1)
        self.entryAIRl.grid(row=2, column=2, padx=2, pady=2)
        self.labelAGRl = tk.Checkbutton(frameREx, variable=self.addGR, text="ガンマ変換", font=font1)
        self.labelAGRl.grid(row=3, column=0, padx=2, pady=2)
        self.labelAG2Rl = tk.Label(frameREx, text="データ数：", font=font1)
        self.labelAG2Rl.grid(row=3, column=1, padx=2, pady=2)
        self.entryAGnRl = tk.Entry(frameREx, width=10, textvariable=self.addGnR, font=font1)
        self.entryAGnRl.grid(row=3, column=2, padx=2, pady=2)
        self.labelAG3Rl = tk.Label(frameREx, text="γ = ", font=font1)
        self.labelAG3Rl.grid(row=3, column=3, padx=2, pady=2)
        self.entryAGgRl = tk.Entry(frameREx, width=10, textvariable=self.addGgR, font=font1)
        self.entryAGgRl.grid(row=3, column=4, padx=2, pady=2)

        self.labelRExT = tk.Label(frameREx, text="テスト用データ数 = ", font=font1)
        self.labelRExT.grid(row=4, column=0, padx=2, pady=2)
        self.entryRExT = tk.Entry(frameREx, width=10, textvariable=self.v_numRExT, font=font1)
        self.entryRExT.grid(row=4, column=1, padx=2, pady=2)
        self.labelAIRt = tk.Checkbutton(frameREx, variable=self.addI2R, text="左右反転", font=font1)
        self.labelAIRt.grid(row=5, column=0, padx=2, pady=2)
        self.labelAI2Rt = tk.Label(frameREx, text="データ数：", font=font1)
        self.labelAI2Rt.grid(row=5, column=1, padx=2, pady=2)
        self.entryAIRt = tk.Entry(frameREx, width=10, textvariable=self.addIn2R, font=font1)
        self.entryAIRt.grid(row=5, column=2, padx=2, pady=2)
        self.labelAGRt = tk.Checkbutton(frameREx, variable=self.addG2R, text="ガンマ変換", font=font1)
        self.labelAGRt.grid(row=6, column=0, padx=2, pady=2)
        self.labelAG2Rt = tk.Label(frameREx, text="データ数：", font=font1)
        self.labelAG2Rt.grid(row=6, column=1, padx=2, pady=2)
        self.entryAGnRt = tk.Entry(frameREx, width=10, textvariable=self.addGn2R, font=font1)
        self.entryAGnRt.grid(row=6, column=2, padx=2, pady=2)
        self.labelAG3Rt = tk.Label(frameREx, text="γ = ", font=font1)
        self.labelAG3Rt.grid(row=6, column=3, padx=2, pady=2)
        self.entryAGgRt = tk.Entry(frameREx, width=10, textvariable=self.addGg2R, font=font1)
        self.entryAGgRt.grid(row=6, column=4, padx=2, pady=2)

        frameMerge = tk.LabelFrame(frameNet, text="統合設定", font=font1, relief=tk.GROOVE, borderwidth = 3)
        frameMerge.grid(row=7, column=0, columnspan=5, padx=2, pady=2, sticky=tk.W+tk.E)
        self.stateM = tk.BooleanVar()
        self.stateM.set(True)
        self.buttonM = tk.Checkbutton(frameMerge, text="統合画像の生成", variable=self.stateM, font=font1)
        self.buttonM.grid(row=0, column=0, padx=2, pady=2)

        frameOther = tk.LabelFrame(self.frame_main, text="その他設定", font=font1, relief=tk.GROOVE, borderwidth = 3)
        frameOther.pack(fill="x", padx=5, pady=5)
        self.EnableGPU = tk.BooleanVar()
        self.EnableGPU.set(self.availableGPU())
        checkgpu = tk.Checkbutton(frameOther, text="GPUを使用", variable=self.EnableGPU, font=("", 12))
        checkgpu.grid(row=0, column=0, padx=5, pady=2)
        if not self.EnableGPU.get():
            checkgpu["state"] = tk.DISABLED

        buttonExe = tk.Button(self.frame_main, text="実行", font=font1)
        buttonExe.bind("<Button-1>", self.execute)
        buttonExe.pack(fill="x")

    def readNetwork(self, event=None):
        fld = filedialog.askdirectory(initialdir = "../networks")

        self.networkFile = fld+"\\network.npz"
        if os.path.exists(fld+"/Constract.pkl"):
            with open(fld+"/Constract.pkl", 'rb') as f:

                const = pickle.load(f)
            self.dataset = const["dataset"]
            self.v_numSG.set(DataNum[self.dataset][0])
            self.v_numRExE.set(DataNum[self.dataset][0])
            self.v_numRExT.set(DataNum[self.dataset][1])
            self.v_ds.set(self.dataset)
            self.layers = const["layers"]
            self.names = ["input"]
            self.names.extend(const["names"])
            self.params = const["params"]
            self.cb_b['values'] = self.names[1:-1]
            self.v_b.set(self.names[self.names.index("Affine1")-1])
            self.addI.set(const["addI"][0])
            self.addIn.set(const["addI"][1])
            self.addG.set(const["addG"][0])
            self.addGn.set(const["addG"][1])
            self.addGg.set(const["addG"][2])
            self.addIR.set(const["addI"][0])
            self.addInR.set(const["addI"][1])
            self.addGR.set(const["addG"][0])
            self.addGnR.set(const["addG"][1])
            self.addGgR.set(const["addG"][2])
            self.addI2R.set(const["addI"][0])
            self.addIn2R.set(const["addI"][1])
            self.addG2R.set(const["addG"][0])
            self.addGn2R.set(const["addG"][1])
            self.addGg2R.set(const["addG"][2])

    def availableGPU(self):
        return chainer.cuda.available

    def execute(self, event=None):
        addI = [self.addI.get(), self.addIn.get()]
        addG = [self.addG.get(), self.addGn.get(), self.addGg.get()]
        addIR = [self.addIR.get(), self.addInR.get()]
        addGR = [self.addGR.get(), self.addGnR.get(), self.addGgR.get()]
        addI2R = [self.addI2R.get(), self.addIn2R.get()]
        addG2R = [self.addG2R.get(), self.addGn2R.get(), self.addGg2R.get()]

        modelR = Model(self.v_ds.get(), self.layers, self.names[1:], self.params, addIR, addGR, addI2R, addG2R, gpu=self.EnableGPU.get())
        modelR.load_Network(self.networkFile)
        modelSG = Model(self.v_ds.get(), self.layers, self.names[1:], self.params, addI, addG, addI2R, addG2R, gpu=self.EnableGPU.get())
        modelSG.load_Network(self.networkFile)

        if self.EnableGPU:
            modelR.toGPU()
            modelSG.toGPU()

        if not os.path.exists("results\\"+self.v_name.get()):
            os.makedirs("results\\"+self.v_name.get())
        with open("results\\"+self.v_name.get()+"\\parameters.txt", "w") as writer:
            writer.write("######################################\n\t\t共通\n######################################\n")
            writer.write("  ・dataset："+self.dataset+"\n")
            writer.write("  ・labels："+Labels[list_datasets.index(self.dataset)])
            writer.write("  ・GPU使用："+str(self.EnableGPU.get())+"\n\n")
            if self.stateREx.get():
                writer.write("######################################\n\t\tルール抽出\n######################################\n")
                writer.write("  ・抽出用データ数："+str(self.v_numRExE.get())+"\n")
                if addIR[0]:
                    writer.write("    左右反転：+"+str(addIR[1])+"\n")
                if addGR[0]:
                    writer.write("    ガンマ変換(γ="+str(addGR[2])+")：+"+str(addGR[1])+"\n")
                writer.write("  ・テスト用データ数："+str(self.v_numRExT.get())+"\n")
                if addI2R[0]:
                    writer.write("    左右反転：+"+str(addI2R[1])+"\n")
                if addG2R[0]:
                    writer.write("    ガンマ変換(γ="+str(addG2R[2])+")：+"+str(addG2R[1])+"\n")
                writer.write("\n")

            if self.stateSG.get():
                writer.write("######################################\n\t\tSmoothGrad\n######################################\n")
                writer.write("  ・正規分布 平均："+str(self.v_na.get())+"\n")
                writer.write("  ・正規分布 標準偏差："+str(self.v_ns.get())+"\n")
                writer.write("  ・使用データ数："+str(self.v_numSG.get())+"\n")
                if addI[0]:
                    writer.write("    左右反転：+"+str(addI[1])+"\n")
                if addG[0]:
                    writer.write("    ガンマ変換(γ="+str(addG[2])+")：+"+str(addG[1])+"\n")
                writer.write("  ・テスト用データ数："+str(self.v_numRExT.get())+"\n")
                writer.write("  ・偏微分 微小値："+str(self.v_d.get())+"\n")

        Executor(self.root, modelR, modelSG, self.dataset, self.stateREx.get(), self.stateSG.get(), self.stateM.get(),
                            "results\\"+self.v_name.get(), self.EnableGPU.get(), self.v_b.get(),
                            [self.v_na.get(), self.v_ns.get(), self.v_numSG.get(), self.v_d.get()],
                            [self.v_numRExE.get(), self.v_numRExT.get()])

    def mergeSwitchSG(self, event=None):
        state = self.stateREx.get() and (not self.stateSG.get())
        self.stateM.set(state)
        if state:
            self.buttonM.configure(state=tk.NORMAL)
            self.labelNA.configure(state=tk.NORMAL)
            self.entryNA.configure(state=tk.NORMAL)
            self.labelNS.configure(state=tk.NORMAL)
            self.entryNS.configure(state=tk.NORMAL)
            self.labelNum.configure(state=tk.NORMAL)
            self.entryNum.configure(state=tk.NORMAL)
            self.labelAI.configure(state=tk.NORMAL)
            self.labelAI2.configure(state=tk.NORMAL)
            self.entryAI.configure(state=tk.NORMAL)
            self.labelAG.configure(state=tk.NORMAL)
            self.labelAG2.configure(state=tk.NORMAL)
            self.entryAGn.configure(state=tk.NORMAL)
            self.labelAG3.configure(state=tk.NORMAL)
            self.entryAGg.configure(state=tk.NORMAL)
            self.labelD.configure(state=tk.NORMAL)
            self.entryD.configure(state=tk.NORMAL)
        else:
            self.buttonM.configure(state=tk.DISABLED)
            self.labelNA.configure(state=tk.DISABLED)
            self.entryNA.configure(state=tk.DISABLED)
            self.labelNS.configure(state=tk.DISABLED)
            self.entryNS.configure(state=tk.DISABLED)
            self.labelNum.configure(state=tk.DISABLED)
            self.entryNum.configure(state=tk.DISABLED)
            self.labelAI.configure(state=tk.DISABLED)
            self.labelAI2.configure(state=tk.DISABLED)
            self.entryAI.configure(state=tk.DISABLED)
            self.labelAG.configure(state=tk.DISABLED)
            self.labelAG2.configure(state=tk.DISABLED)
            self.entryAGn.configure(state=tk.DISABLED)
            self.labelAG3.configure(state=tk.DISABLED)
            self.entryAGg.configure(state=tk.DISABLED)
            self.labelD.configure(state=tk.DISABLED)
            self.entryD.configure(state=tk.DISABLED)

    def mergeSwitchR(self, event=None):
        state = (not self.stateREx.get()) and self.stateSG.get()
        self.stateM.set(state)
        if state:
            self.buttonM.configure(state=tk.NORMAL)
            self.labelRExE.configure(state=tk.NORMAL)
            self.entryRExE.configure(state=tk.NORMAL)
            self.labelAIRl.configure(state=tk.NORMAL)
            self.labelAI2Rl.configure(state=tk.NORMAL)
            self.entryAIRl.configure(state=tk.NORMAL)
            self.labelAGRl.configure(state=tk.NORMAL)
            self.labelAG2Rl.configure(state=tk.NORMAL)
            self.entryAGnRl.configure(state=tk.NORMAL)
            self.labelAG3Rl.configure(state=tk.NORMAL)
            self.entryAGgRl.configure(state=tk.NORMAL)
            self.labelRExT.configure(state=tk.NORMAL)
            self.entryRExT.configure(state=tk.NORMAL)
            self.labelAIRt.configure(state=tk.NORMAL)
            self.labelAI2Rt.configure(state=tk.NORMAL)
            self.entryAIRt.configure(state=tk.NORMAL)
            self.labelAGRt.configure(state=tk.NORMAL)
            self.labelAG2Rt.configure(state=tk.NORMAL)
            self.entryAGnRt.configure(state=tk.NORMAL)
            self.labelAG3Rt.configure(state=tk.NORMAL)
            self.entryAGgRt.configure(state=tk.NORMAL)
        else:
            self.buttonM.configure(state=tk.DISABLED)
            self.labelRExE.configure(state=tk.DISABLED)
            self.entryRExE.configure(state=tk.DISABLED)
            self.labelAIRl.configure(state=tk.DISABLED)
            self.labelAI2Rl.configure(state=tk.DISABLED)
            self.entryAIRl.configure(state=tk.DISABLED)
            self.labelAGRl.configure(state=tk.DISABLED)
            self.labelAG2Rl.configure(state=tk.DISABLED)
            self.entryAGnRl.configure(state=tk.DISABLED)
            self.labelAG3Rl.configure(state=tk.DISABLED)
            self.entryAGgRl.configure(state=tk.DISABLED)
            self.labelRExT.configure(state=tk.DISABLED)
            self.entryRExT.configure(state=tk.DISABLED)
            self.labelAIRt.configure(state=tk.DISABLED)
            self.labelAI2Rt.configure(state=tk.DISABLED)
            self.entryAIRt.configure(state=tk.DISABLED)
            self.labelAGRt.configure(state=tk.DISABLED)
            self.labelAG2Rt.configure(state=tk.DISABLED)
            self.entryAGnRt.configure(state=tk.DISABLED)
            self.labelAG3Rt.configure(state=tk.DISABLED)
            self.entryAGgRt.configure(state=tk.DISABLED)

    def getRoot(self):
        return self.root

if __name__ == '__main__':
    ui = UI()
    ui.getRoot().mainloop()