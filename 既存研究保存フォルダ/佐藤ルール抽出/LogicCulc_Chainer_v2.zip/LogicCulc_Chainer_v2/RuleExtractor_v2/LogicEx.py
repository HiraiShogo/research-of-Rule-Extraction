import numpy as np
import cupy as cp
import os

class Logic_Extract(object):
    def __init__(self, t_size, path, gpu, pr):
        self.rule = [{} for _ in range(t_size)]
        self.ruleMS = [{} for _ in range(t_size)]
        self.ruleList = [[] for _ in range(t_size)]
        self.mat = None
        self.path = path + "\\logics"
        self.pr = pr
        if not os.path.exists(self.path+"\\results"):
            os.makedirs(self.path+"\\results")
        if gpu:
            self.mat = cp
        else:
            self.mat = np

    def extract(self, x, y):
        y_a = self.mat.argmax(y, axis=1)
        #print(int(y_a[0]))
        for i in range(len(x)):
            self.pr(i)
            (s, sMS, sl) = self.mat2logic(x[i])
            if s in self.rule[int(y_a[i])].keys():
                self.rule[int(y_a[i])][s] += 1
                l = self.ruleList[int(y_a[i])]
                for ind in range(len(l)):
                    b = l[ind][0] == sl
                    if all(b):
                        l[ind][1] += 1
                        break

            else:
                self.rule[int(y_a[i])][s] = 1
                self.ruleMS[int(y_a[i])][s] = sMS
                self.ruleList[int(y_a[i])].append([sl, 1])

    def getRule(self):
        return self.ruleList

    def saveLogic(self):
        for r in range(len(self.rule)):
            with open(self.path+"\\results\\unit-"+str(r)+".txt", "w") as f:
                for k, v in self.rule[r].items():
                    f.write(k+"\t"+str(v)+"\n")
                f.write("\n\n")
                for k, v in self.rule[r].items():
                    f.write(self.ruleMS[r][k]+"\t"+str(v)+"\n")

    def test(self, x, t, y):
        corrects = 0
        semi_c = 0
        outputL = []
        with open(self.path+"\\test.txt", "w") as f:
            for i in range(len(x)):
                self.pr(i)
                f.write("input = "+str(x[i])+"\n")
                s = self.mat2logic(x[i])[0]
                a = -1
                b = []
                n = -1
                for r in range(len(self.rule)):
                    if s in self.rule[r].keys():
                        b.append(r)
                        f.write("\t\""+str(r)+"\"："+str(self.rule[r][s])+"\n")
                        if self.rule[r][s] > a:
                            a = self.rule[r][s]
                            n = r
                outputL.append(n)
                f.write("→ output = "+str(n)+", ans = "+str(t[i]))
                if n == t[i]:
                    f.write(" ○\n")
                    corrects += 1
                elif t[i] in b:
                    f.write(" △\n")
                    semi_c += 1
                else:
                    f.write(" ×\n")
                f.write("\n")
            noa = self.mat.sum(self.mat.array(outputL) == y)
            f.write("\nAccuracy = "+str(corrects / len(x)))
            f.write("\nSemi_Accuracy = "+str((corrects+semi_c) / len(x)))
            f.write("\nNetwork-output Accuracy = "+str(noa / len(y)))

    def mat2logic(self, x):
        x = x >= 0.5
        s = ""
        sMS = ""
        for i in range(len(x)):
            if x[i]:
                if len(s) == 0:
                    s += "P_x"+str(i)
                    sMS += "x_"+str(i)
                else:
                    s += " ∧ P_x"+str(i)
                    sMS += "∧x_"+str(i)
            else:
                if len(s) == 0:
                    s += "N_x"+str(i)
                    sMS += "(x_"+str(i)+")\\bar"
                else:
                    s += " ∧ N_x"+str(i)
                    sMS += "∧(x_"+str(i)+")\\bar"
        return (s, sMS, x)