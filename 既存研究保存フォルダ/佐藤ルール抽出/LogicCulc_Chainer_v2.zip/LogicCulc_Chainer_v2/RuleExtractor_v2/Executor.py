#tkinter
import tkinter as tk
import tkinter.ttk as ttk
import tkinter.font as font
import tkinter.scrolledtext as sc
from tkinter import filedialog

#その他
import threading
from LogicEx import Logic_Extract  # @UnresolvedImport
from ImageEx import Image_Extract  # @UnresolvedImport
import numpy as np
import cupy as cp
import re
import subprocess
import json
import pickle
import time
import os
from RuleExtractor_v2.MergeEx import MergeExecutor

class Executor:
    def __init__(self, root, modelR, modelSG, dataset, r, sg, m, path, gpu, border, paramsSG, paramsR):
        font1 = ("", 12)

        self.modelR = modelR
        self.modelSG = modelSG
        self.paramsSG = paramsSG
        self.paramsR = paramsR
        self.border = border

        self.dataset = dataset

        self.r = r
        self.sg = sg
        self.m = m

        self.path = path
        self.gpu = gpu

        self.resultL = None
        self.resultSG = None

        self.mat = 0
        if gpu:
            self.mat = cp
        else:
            self.mat = np

        self.Ended_R = False
        self.Ended_SG = False
        self.sgval = 0

        self.rootE = tk.Toplevel(root)
        self.rootE.title("Rule Extractor Console")
        self.rootE.geometry("450x610")

        frameSG = tk.LabelFrame(self.rootE, text="SmoothGrad", font=font1, relief=tk.GROOVE, borderwidth=4)
        frameSG.pack(fill="x", padx=10, pady=3)
        self.pbSG = ttk.Progressbar(frameSG,orient=tk.HORIZONTAL,length=200,mode='determinate')
        self.pbSG.configure(maximum=paramsSG[2], value=0)
        self.pbSG.pack(fill="x")
        self.consoleSG = sc.ScrolledText(frameSG, width=50, height=15, font=font1)
        self.consoleSG.pack(fill="both")

        frameR = tk.LabelFrame(self.rootE, text="ルール抽出", font=font1, relief=tk.GROOVE, borderwidth=4)
        frameR.pack(fill="x", padx=10, pady=3)
        self.pbR = ttk.Progressbar(frameR,orient=tk.HORIZONTAL,length=200,mode='determinate')
        self.pbR.configure(maximum=paramsR[0], value=0)
        self.pbR.pack(fill="x")
        #pbR1.configure(maximum=paramsR[1], value=self.progressR2)
        self.consoleR = sc.ScrolledText(frameR, width=50, height=7, font=font1)
        self.consoleR.pack(fill="both")

        frameM = tk.LabelFrame(self.rootE, text="統合", font=font1, relief=tk.GROOVE, borderwidth=4)
        frameM.pack(fill="x", padx=10, pady=3)
        self.pbM = ttk.Progressbar(frameM,orient=tk.HORIZONTAL,length=200,mode='determinate')
        self.pbM.configure(maximum=paramsR[0], value=0)
        self.pbM.pack(fill="x")
        #pbR1.configure(maximum=paramsR[1], value=self.progressR2)
        self.consoleM = sc.ScrolledText(frameM, width=50, height=7, font=font1)
        self.consoleM.pack(fill="both")

        self.rootE.after(10, self.startEx)

    def execute(self):
        e = None
        sg = None
        if self.r:
            e = threading.Thread(target=self.executeR)
            e.start()
        else:
            self.consoleR.insert(tk.END, "############################################\nNot Available\n############################################")
        if self.sg:
            sg = threading.Thread(target=self.executeSG)
            sg.start()
        else:
            self.consoleSG.insert(tk.END, "############################################\nNot Available\n############################################")
        if not self.m:
            self.consoleM.insert(tk.END, "############################################\nNot Available\n############################################")
        else:
            self.consoleM.insert(tk.END, "Waiting for Executing RuleExtract and SmoothGrad...")
        if self.r:
            e.join()
        if self.sg:
            sg.join()
        if self.m:
            self.consoleM.insert(tk.END, "OK\n\n")
            self.executeM()


        subprocess.Popen(['explorer',"results\\"+self.path])

    def startEx(self):
        threading.Thread(target=self.execute).start()

    def executeR(self):
        start = time.time()
        key = [self.border, "output"]

        self.consoleR.insert(tk.END, "Culculating outputs for Extraction...")
        output = self.modelR.predict_Trains(num=self.paramsR[0], key=key)
        for k, v in output.items():
            output[k] = v.reshape((len(v), -1))
        self.consoleR.insert(tk.END, "OK\n")
        l = Logic_Extract(len(output[key[-1]][0]), self.path, self.gpu, self.set_progressR)
        self.consoleR.insert(tk.END, "Extracting Rules...")
        l.extract(output[key[0]], output[key[1]])
        self.resultL = l.getRule()
        self.consoleR.insert(tk.END, "OK\n")

        self.consoleR.insert(tk.END, "Saving Rules...")
        l.saveLogic()
        self.consoleR.insert(tk.END, "OK\n")

        self.pbR.configure(maximum=self.paramsR[1], value=0)
        self.consoleR.insert(tk.END, "Culculating outputs for Testing Rules...")
        output = self.modelR.predict_Tests(num=self.paramsR[1], key=[self.border, "output"])
        Poutput = output[self.border].reshape((self.paramsR[1], -1))
        Poutput = (Poutput>=0.5).astype("int")
        output = self.mat.argmax(output["output"], axis=1)
        t = [i[1] for i in self.modelR.getTests()]
        self.consoleR.insert(tk.END, "OK\n")
        self.consoleR.insert(tk.END, "Testing Rules...")
        l.test(Poutput, t, output)
        self.consoleR.insert(tk.END, "OK\n")
        end = time.time()

        self.consoleR.insert(tk.END, "\nLogic Extraction has finished\n")
        self.consoleR.insert(tk.END, "    elapsed time = "+self.secs2label(end-start)+"\n")

        self.Ended_R = True

    def secs2label(self, secs):
        s = ""
        if secs/3600 > 1:
            s += str(int(secs // 3600))+" hour(s) "
            secs = secs % 3600
        if secs/60 > 1:
            s += str(int(secs // 60))+" min(s) "
            secs = secs % 60
        s += str(round(secs, 2))+"sec(s)"
        return s

    def set_progressR(self, val):
        self.pbR.configure(value=val)

    def set_progressSG(self, val):
        self.pbSG.configure(value=val)

    def add_ConsoleSG(self, txt):
        self.consoleSG.insert(tk.END, txt)
        self.consoleSG.see("end")

    def set_progressM(self, val):
        self.pbM.configure(value=val)

    def add_ConsoleM(self, txt):
        self.consoleM.insert(tk.END, txt)
        self.consoleM.see("end")

    def executeSG(self):
        start = time.time()
        self.consoleSG.insert(tk.END, "Creating Input Images...")
        inputImages = self.mat.array([self.modelSG.getTrain(num=i) for i in range(self.paramsSG[2])])
        inputImages += self.mat.random.normal(loc=self.paramsSG[0], scale=self.paramsSG[1], size=inputImages.shape)
        self.consoleSG.insert(tk.END, "OK\n")

        self.consoleSG.insert(tk.END, "SmoothGrad method\n")
        self.consoleSG.insert(tk.END, "  Culculating output of no diffs...")
        y = self.modelSG.predict_X(inputImages, key=[self.border])
        y = y[self.border]
        y = self.mat.sum(self.mat.asarray(y), axis=0)
        self.consoleSG.insert(tk.END, "OK\n")

        sg = Image_Extract(self.modelSG, self.dataset, self.paramsSG[3], self.border, self.path, self.gpu, self.add_ConsoleSG, self.set_progressSG)
        self.resultSG = sg.smoothGrad(inputImages, y)
        end = time.time()

        self.consoleSG.insert(tk.END, "\nImage Extraction has finished\n")
        self.consoleSG.insert(tk.END, "    elapsed time = "+self.secs2label(end-start)+"\n")
        self.consoleSG.see("end")

        self.Ended_SG = True

    def executeM(self):
        start = time.time()
        self.consoleM.insert(tk.END, "Merging Rules and Images ....\n")
        merge = MergeExecutor(self.dataset, self.path, self.set_progressM, self.add_ConsoleM, self.gpu)
        merge.merge(self.resultL, self.resultSG)
        self.consoleM.insert(tk.END, "OK\n")
        self.consoleM.insert(tk.END, "Saving Merged Images ....\n")
        merge.saveImage()
        self.consoleM.insert(tk.END, "OK\n")
        end = time.time()

        self.consoleM.insert(tk.END, "\nMerging has finished\n")
        self.consoleM.insert(tk.END, "    elapsed time = "+self.secs2label(end-start)+"\n")